#include <stdbool.h>
bool associabili(int N, int* v1, int* v2) {
    return true;
}
